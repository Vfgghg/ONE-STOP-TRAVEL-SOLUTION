/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Traveling;

/**
 *
 * @author INVALID
 */
class cFlight {
    
    public double Nigeria = 560;
    public double Canada_Torrent = 430;
    public double Canada_O = 460;
    public double India = 460;
    public double Italy = 598;
    public double USA = 550;
    public double Kenya = 890;
    public double Norway = 760;
    public double Ghana = 920;
    public double South_Afira = 360;
    public double UK_London = 160;
    public double France = 1090;
    public double Bangladesh = 990;
}
